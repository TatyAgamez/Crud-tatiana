package corp.dataa.dataa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataaApplication.class, args);
	}

}
