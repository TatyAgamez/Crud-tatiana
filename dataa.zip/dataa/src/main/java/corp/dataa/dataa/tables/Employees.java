package corp.dataa.dataa.tables;

public class Employees {
    private int id;
    private String last_name;
    private String phone_number;
    private String email;
    private String hire_date;
    private String job_id;

    public Employees(String last_name, String phone_number,
                     String email, String hire_date, String job_id) {
        this.last_name = last_name;
        this.phone_number = phone_number;
        this.email = email;
        this.hire_date = hire_date;
        this.job_id = job_id;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getHire_date() {
        return hire_date;
    }

    public void setHire_date(String hire_date) {
        this.hire_date = hire_date;
    }

    public String getJob_id() {
        return job_id;
    }

    public void setJob_id(String job_id) {
        this.job_id = job_id;
    }
}
